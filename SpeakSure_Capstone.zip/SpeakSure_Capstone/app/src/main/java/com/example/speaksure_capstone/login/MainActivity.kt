package com.example.speaksure_capstone.login

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.speaksure_capstone.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}